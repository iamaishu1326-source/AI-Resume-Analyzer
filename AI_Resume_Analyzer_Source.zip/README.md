# AI Resume Analyzer

A Django project that lets users register, upload a PDF/DOCX/TXT resume, extract text-based skills, and compare those skills with saved job roles.

## Requirements
- Python 3.10+
- pip

## Run locally
1. Open a terminal in the folder containing `manage.py`.
2. Create and activate a virtual environment (recommended).
3. Install dependencies: `python -m pip install -r requirements.txt`
4. Create database tables: `python manage.py migrate`
5. Create an admin user if needed: `python manage.py createsuperuser`
6. Start the app: `python manage.py runserver`
7. Open http://127.0.0.1:8000/

## Features
- Landing page, registration, login, logout
- Private user dashboard and profile
- Upload PDF, DOCX, or TXT resumes
- Basic keyword-based skill extraction (not a full AI/ATS judgement)
- Job role matching based on required skills
- Resume history and analysis result pages
- Django admin for job-role management

## Important
- Scanned/image-only PDFs need OCR; this starter extracts selectable text from PDFs and does not promise OCR for scanned documents.
- Skill matching is a simple keyword comparison, not a hiring recommendation.
- Before deployment, configure a secure `SECRET_KEY`, `DEBUG=False`, `ALLOWED_HOSTS`, HTTPS, and a production database/storage provider. Never commit real credentials, personal resumes, or `db.sqlite3`.
- GitHub Pages cannot run Django/Python. Deploy the Django app to a Python-capable host; GitHub can store the source code.
