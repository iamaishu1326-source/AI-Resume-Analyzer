# Initial database schema for AI Resume Analyzer.
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(name="JobRole", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("role_name", models.CharField(max_length=100, unique=True)),
            ("required_skills", models.TextField(help_text="Comma-separated skills")),
        ]),
        migrations.CreateModel(name="Profile", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("skills", models.TextField(blank=True)), ("education", models.TextField(blank=True)),
            ("user", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL)),
        ]),
        migrations.CreateModel(name="Resume", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("resume_file", models.FileField(upload_to="resumes/")),
            ("uploaded_at", models.DateTimeField(auto_now_add=True)),
            ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="resumes", to=settings.AUTH_USER_MODEL)),
        ]),
        migrations.CreateModel(name="SkillAnalysis", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("extracted_skills", models.TextField()), ("score", models.FloatField(default=0)),
            ("extracted_text", models.TextField(blank=True)), ("created_at", models.DateTimeField(auto_now_add=True)),
            ("resume", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="analyses", to="Core.resume")),
        ]),
    ]
