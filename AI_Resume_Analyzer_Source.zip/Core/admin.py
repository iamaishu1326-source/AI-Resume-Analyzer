from django.contrib import admin
from .models import Profile, Resume, SkillAnalysis, JobRole

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ("user",)
@admin.register(Resume)
class ResumeAdmin(admin.ModelAdmin):
    list_display = ("user", "resume_file", "uploaded_at")
@admin.register(SkillAnalysis)
class SkillAnalysisAdmin(admin.ModelAdmin):
    list_display = ("resume", "score", "created_at")
@admin.register(JobRole)
class JobRoleAdmin(admin.ModelAdmin):
    list_display = ("role_name",)
    search_fields = ("role_name", "required_skills")
