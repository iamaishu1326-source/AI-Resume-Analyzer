from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("register/", views.register_view, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("profile/", views.profile_view, name="profile"),
    path("resumes/upload/", views.resume_upload, name="resume_upload"),
    path("resumes/", views.resume_list, name="resume_list"),
    path("resumes/<int:pk>/", views.resume_detail, name="resume_detail"),
    path("resumes/<int:pk>/delete/", views.delete_resume, name="delete_resume"),
    path("job-roles/", views.job_roles, name="job_roles"),
]
