from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    skills = models.TextField(blank=True)
    education = models.TextField(blank=True)
    def __str__(self):
        return self.user.username

class Resume(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="resumes")
    resume_file = models.FileField(upload_to="resumes/")
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.user.username} - {self.resume_file.name}"

class SkillAnalysis(models.Model):
    resume = models.ForeignKey(Resume, on_delete=models.CASCADE, related_name="analyses")
    extracted_skills = models.TextField()
    score = models.FloatField(default=0)
    extracted_text = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"Analysis - {self.resume.user.username}"

class JobRole(models.Model):
    role_name = models.CharField(max_length=100, unique=True)
    required_skills = models.TextField(help_text="Comma-separated skills")
    def __str__(self):
        return self.role_name
