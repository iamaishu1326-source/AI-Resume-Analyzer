from django.test import TestCase
from .views import extract_skills, score_match

class SkillMatchingTests(TestCase):
    def test_extracts_skills(self):
        self.assertIn("Python", extract_skills("I use Python and Django for web development"))
    def test_match_score(self):
        self.assertEqual(score_match(["Python", "Django"], ["Python", "Django", "SQL"]), 66.7)
