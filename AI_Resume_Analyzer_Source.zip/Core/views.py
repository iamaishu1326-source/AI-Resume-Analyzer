import re
from pathlib import Path
from docx import Document
from PyPDF2 import PdfReader
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.shortcuts import render, redirect, get_object_or_404
from django.utils.text import get_valid_filename
from .models import Profile, Resume, SkillAnalysis, JobRole

COMMON_SKILLS = [
    "Python", "Java", "JavaScript", "TypeScript", "C", "C++", "C#", "SQL",
    "Django", "Flask", "FastAPI", "HTML", "CSS", "React", "Node.js",
    "REST API", "Git", "GitHub", "Linux", "Excel", "Power BI", "Tableau",
    "Pandas", "NumPy", "Machine Learning", "Deep Learning", "Artificial Intelligence",
    "OCR", "NLP", "Data Analysis", "Data Visualization", "MySQL", "PostgreSQL",
    "SQLite", "MongoDB", "AWS", "Azure", "Docker", "Kubernetes", "Communication",
    "Problem Solving", "Teamwork", "Leadership", "Project Management", "Agile",
    "Bootstrap", "PHP", "WordPress", "Figma", "Cybersecurity", "Testing",
]

def extract_text(file_path):
    ext = Path(file_path).suffix.lower()
    if ext == ".pdf":
        reader = PdfReader(file_path)
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if ext == ".docx":
        doc = Document(file_path)
        parts = [p.text for p in doc.paragraphs]
        for table in doc.tables:
            for row in table.rows:
                parts.append(" ".join(cell.text for cell in row.cells))
        return "\n".join(parts)
    if ext == ".txt":
        return Path(file_path).read_text(encoding="utf-8", errors="ignore")
    raise ValueError("Please upload a PDF, DOCX, or TXT file.")

def extract_skills(text):
    lower = text.lower()
    found = []
    for skill in COMMON_SKILLS:
        # Match whole words where possible, so e.g. C does not match every word.
        pattern = r"(?<![a-z0-9+#])" + re.escape(skill.lower()) + r"(?![a-z0-9+#])"
        if re.search(pattern, lower):
            found.append(skill)
    return sorted(set(found), key=str.lower)

def split_skills(value):
    return [s.strip() for s in re.split(r"[,;\n]", value or "") if s.strip()]

def score_match(resume_skills, required_skills):
    required = {s.casefold() for s in required_skills if s.strip()}
    if not required:
        return 0.0
    matched = {s.casefold() for s in resume_skills} & required
    return round(100 * len(matched) / len(required), 1)

def home(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    return render(request, "core/home.html")

def register_view(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            Profile.objects.get_or_create(user=user)
            login(request, user)
            messages.success(request, "Account created. Welcome to AI Resume Analyzer!")
            return redirect("dashboard")
    else:
        form = UserCreationForm()
    return render(request, "core/register.html", {"form": form})

def login_view(request):
    from django.contrib.auth import authenticate
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "")
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("dashboard")
        messages.error(request, "Invalid username or password.")
    return render(request, "core/login.html")

def logout_view(request):
    if request.method == "POST":
        logout(request)
        messages.success(request, "You have been logged out.")
    return redirect("home")

@login_required
def dashboard(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)
    resumes = Resume.objects.filter(user=request.user).order_by("-uploaded_at")
    analyses = SkillAnalysis.objects.filter(resume__user=request.user)
    return render(request, "core/dashboard.html", {
        "profile": profile, "resumes": resumes[:5], "resume_count": resumes.count(),
        "analysis_count": analyses.count(), "job_role_count": JobRole.objects.count(),
    })

@login_required
def profile_view(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)
    if request.method == "POST":
        profile.skills = request.POST.get("skills", "").strip()
        profile.education = request.POST.get("education", "").strip()
        profile.save()
        messages.success(request, "Profile saved.")
        return redirect("profile")
    return render(request, "core/profile.html", {"profile": profile})

@login_required
def resume_upload(request):
    if request.method == "POST":
        uploaded = request.FILES.get("resume_file")
        if not uploaded:
            messages.error(request, "Choose a resume file first.")
            return redirect("resume_upload")
        ext = Path(uploaded.name).suffix.lower()
        if ext not in {".pdf", ".docx", ".txt"}:
            messages.error(request, "Supported formats are PDF, DOCX, and TXT.")
            return redirect("resume_upload")
        if uploaded.size > 8 * 1024 * 1024:
            messages.error(request, "File must be 8 MB or smaller.")
            return redirect("resume_upload")
        resume = Resume(user=request.user, resume_file=uploaded)
        resume.save()
        try:
            text = extract_text(resume.resume_file.path)
            skills = extract_skills(text)
            SkillAnalysis.objects.create(
                resume=resume, extracted_skills=", ".join(skills) if skills else "",
                score=0, extracted_text=text[:30000],
            )
        except Exception as exc:
            resume.delete()
            messages.error(request, f"Could not read that file: {exc}")
            return redirect("resume_upload")
        if not text.strip():
            messages.warning(request, "No selectable text was found. Scanned PDFs need OCR; try a text-based PDF or DOCX.")
        else:
            messages.success(request, f"Resume analyzed. Found {len(skills)} recognizable skills.")
        return redirect("resume_detail", pk=resume.pk)
    return render(request, "core/resume_upload.html")

@login_required
def resume_list(request):
    resumes = Resume.objects.filter(user=request.user).order_by("-uploaded_at")
    return render(request, "core/resume_list.html", {"resumes": resumes})

@login_required
def resume_detail(request, pk):
    resume = get_object_or_404(Resume, pk=pk, user=request.user)
    analysis = resume.analyses.order_by("-created_at").first()
    resume_skills = split_skills(analysis.extracted_skills if analysis else "")
    matches = []
    for role in JobRole.objects.all():
        required = split_skills(role.required_skills)
        matched = [s for s in resume_skills if s.casefold() in {r.casefold() for r in required}]
        matches.append({"role": role, "score": score_match(resume_skills, required), "matched": matched,
                        "missing": [r for r in required if r.casefold() not in {s.casefold() for s in resume_skills}]})
    matches.sort(key=lambda item: item["score"], reverse=True)
    if analysis and matches:
        analysis.score = matches[0]["score"]
        analysis.save(update_fields=["score"])
    return render(request, "core/resume_detail.html", {
        "resume": resume, "analysis": analysis, "skills": resume_skills, "matches": matches[:8],
    })

@login_required
def job_roles(request):
    if request.method == "POST":
        name = request.POST.get("role_name", "").strip()
        skills = request.POST.get("required_skills", "").strip()
        if not name or not skills:
            messages.error(request, "Enter both a role name and required skills.")
        else:
            JobRole.objects.update_or_create(role_name=name, defaults={"required_skills": skills})
            messages.success(request, "Job role saved.")
        return redirect("job_roles")
    return render(request, "core/job_roles.html", {"roles": JobRole.objects.order_by("role_name")})

@login_required
def delete_resume(request, pk):
    resume = get_object_or_404(Resume, pk=pk, user=request.user)
    if request.method == "POST":
        resume.delete()
        messages.success(request, "Resume deleted.")
        return redirect("resume_list")
    return render(request, "core/delete_resume.html", {"resume": resume})
